package com.tvdinh.app.repository;

import com.tvdinh.app.domain.readmodel.ITotalUser;
import com.tvdinh.app.entity.UserEntity;
import com.tvdinh.app.repository.custom.UserRepositoryCustom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<UserEntity, String>, UserRepositoryCustom {

    @Query("from UserEntity e where e.deleted = false and lower(e.username) = lower(:username)")
    Optional<UserEntity> findByUsername(@Param("username") String username);

    @Query("select coalesce(sum(case when r.code = :studentCode then 1 else 0 end), 0) as totalStudent, " +
            " coalesce(sum(case when r.code = :teacherCode then 1 else 0 end), 0) as totalTeacher " +
            " from UserEntity u join RoleEntity r on r.id = u.roleId where u.deleted = false")
    ITotalUser totalUser(String studentCode, String teacherCode);

}
