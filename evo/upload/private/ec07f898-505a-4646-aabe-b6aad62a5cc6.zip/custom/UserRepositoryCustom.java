package com.tvdinh.app.repository.custom;

import com.tvdinh.app.dto.UserSearchRequest;
import com.tvdinh.app.entity.UserEntity;

import java.util.List;

public interface UserRepositoryCustom {

    List<UserEntity> search(UserSearchRequest request);

    Long count(UserSearchRequest request);

}
