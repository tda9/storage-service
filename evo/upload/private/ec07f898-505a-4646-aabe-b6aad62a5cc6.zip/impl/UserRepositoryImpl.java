package com.tvdinh.app.repository.impl;

import com.tvdinh.app.dto.UserSearchRequest;
import com.tvdinh.app.entity.UserEntity;
import com.tvdinh.app.repository.custom.UserRepositoryCustom;
import com.tvdinh.app.utils.SqlUtils;
import com.tvdinh.app.utils.StrUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserRepositoryImpl implements UserRepositoryCustom {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<UserEntity> search(UserSearchRequest request) {
        Map<String, Object> values = new HashMap<>();
        String sql = "select e from UserEntity e " + createWhereQuery(request, values) + createOrderQuery(request.getSortBy());
        Query query = entityManager.createQuery(sql, UserEntity.class);
        values.forEach(query::setParameter);
        query.setFirstResult((request.getPageIndex() - 1) * request.getPageSize());
        query.setMaxResults(request.getPageSize());
        return query.getResultList();
    }

    @Override
    public Long count(UserSearchRequest request) {
        Map<String, Object> values = new HashMap<>();
        String sql = "select count(e) from UserEntity e " + createWhereQuery(request, values);
        Query query = entityManager.createQuery(sql, Long.class);
        values.forEach(query::setParameter);
        return (Long) query.getSingleResult();
    }

    private String createWhereQuery(UserSearchRequest request, Map<String, Object> values) {
        StringBuilder sql = new StringBuilder();
        sql.append(" left join RoleEntity r on (e.roleId = r.id) ");
        sql.append(" where e.deleted = false");
        if (StrUtils.isNotBlank(request.getKeyword())) {
            sql.append(
                    " and ( lower(e.username) like :keyword"
                            + " or lower(e.email) like :keyword"
                            + " or lower(e.code) like :keyword"
                            + " or lower(e.fullName) like :keyword"
                            + " or lower(e.phoneNumber) like :keyword"
                            + " or lower(r.name) like :keyword ) ");
            values.put("keyword", SqlUtils.encodeKeyword(request.getKeyword()));
        }
        if (StrUtils.isNotBlank(request.getType())) {
            sql.append(" and r.code = :roleCode ");
            values.put("roleCode", request.getType());
        }
        if (!CollectionUtils.isEmpty(request.getStatuses())) {
            sql.append(" and e.status in :statuses ");
            values.put("statuses", request.getStatuses());
        }
        return sql.toString();
    }

    public StringBuilder createOrderQuery(String sortBy) {
        StringBuilder hql = new StringBuilder(" ");
        if (StringUtils.hasLength(sortBy)) {
            hql.append(" order by e.").append(sortBy.replace(".", " "));
        } else {
            hql.append(" order by e.lastModifiedAt desc ");
        }
        return hql;
    }
}
